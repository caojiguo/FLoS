# The estimator of c using the subsample data selected by uniform probability
#' @title The function to get the estimator of B-spline basis coefficient
#' using the subsample data selected by the uniform subsampling method
#' @description The function to get the estimator of basis coefficient
#' using the subsample data selected by the uniform subsampling method.

#' @param N The design matrix.
#' @param yc The centered response vector.
#' @param r The subsample size to draw a random subsample with replacement.
#' @param lambda A non-negative smoothing parameter
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.

#' @return A vector of the estimated B-spline basis coefficients using the
#' uniform subsampling method.



Unisub = function(N, yc, r, lambda, V)
{
  n = dim(N)[1]
  index_uni0= sample(1:n,r, replace = TRUE)
  N_uni0 = N[index_uni0,]
  y_uni0 = yc[index_uni0]
  W_uni = diag(n/r,r)

  # calculate c0
  A0 = t(N_uni0)%*%W_uni%*%N_uni0+lambda*V
  B0 = t(N_uni0)%*%W_uni%*%y_uni0
  c0 = ginv(A0)%*%B0
  return(c = c0)
}
