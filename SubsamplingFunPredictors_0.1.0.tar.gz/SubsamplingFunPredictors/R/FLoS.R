# The estimator of c using the subsample data selected by the FLoS
#' @title The function to get the estimator of B-spline basis coefficient
#' using the subsample data selected by the FLoS method
#' @description The function to get the estimator of basis coefficient
#' using the subsample data selected by the FLoS method, which
#' are described in Liu et al (2021) in the reference.

#' @param N The design matrix.
#' @param N_norm A vector with \emph{i}th element is the norm of
#' the \emph{i}th row of the design matrix N.
#' @param yc The centered response vector.
#' @param r The subsample size to draw a random subsample with replacement.
#' @param r0 The subsample size used to get the pilot estimator
#' of the basis coefficients.
#' @param lambda A non-negative smoothing parameter
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.

#' @return A vector of the estimated B-spline basis coefficients using the
#' L-optimality motivated Algorithm 1 described in the reference Liu et al (2021).

#' @references H.Liu, J.You, J.Cao (2021).
#' Functional L-Optimality Subsampling for Massive Data.
#' @author Hua Liu, Jinhong You and Jiguo Cao

FLoS = function(N, N_norm, yc, r, r0, lambda, V )
{
  n = dim(N)[1]

  ###############################################
  #    Step 1: subsampel using the uniform      #
  #            sampling probabilities 1/n       #
  ###############################################
  index_uni0= sample(1:n,r0, replace = FALSE)
  N_uni0 = N[index_uni0,]
  y_uni0 = yc[index_uni0]

  # calculate c0
  A0 = t(N_uni0)%*%N_uni0
  B0 = t(N_uni0)%*%y_uni0
  # c0 = ginv(t(N_uni0)%*%N_uni0+lambda*V)%*%t(N_uni0)%*%y_uni0
  c0 = ginv(A0)%*%B0

  ###############################################
  #    Step 2: calculate the sampling           #
  #            probabilities p_FLoS             #
  ###############################################
  # N_norm = apply(N,1,norm,"2")
  # N_norm = rowNorms(N, "euclidean")
  res = yc - N%*%c0
  p_FLoS = abs(res)*N_norm/sum(abs(res)*N_norm)

  # subsample using p_FLoS
  index_FLoS= sample(1:n,r, prob =  p_FLoS,replace = TRUE)
  N_FLoS = N[index_FLoS,]
  y_FLoS = yc[index_FLoS]
  p_s_FLoS = p_FLoS[index_FLoS]
  W_FLoS = diag(1/(r*p_s_FLoS))

  ###############################################
  #    Step 3: estimate using the               #
  #            subsample data                   #
  ###############################################

  # estimate using the subsample data
  # c_FLoS = ginv(t(N_FLoS)%*%W_FLoS%*%N_FLoS+lambda*V)%*%t(N_FLoS)%*%W_FLoS%*%y_FLoS
  A_FLoS = t(N_FLoS)%*%W_FLoS%*%N_FLoS+lambda*V
  B_FLoS = t(N_FLoS)%*%W_FLoS%*%y_FLoS
  c_FLoS = ginv(A_FLoS)%*%B_FLoS
  return(c = c_FLoS)
}
