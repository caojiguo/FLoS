# inverse of the link function
#' @title The value of the inverse link function
#' @description The value of the inverse link function.
#' @param x A numeric or complex vector or array.
#' @param family A description of the distribution of the
#' response variable
#' in the scalar-on-function generalized linear model,
#' e.g. "Binomial" and "Possion".

#' @return The value of the inverse link function.
psi = function(x, family)
{
  if(family == "Binomial") {p = exp(x)/(1+exp(x))}
  else if(family == "Possion") {p = exp(x)}
  else{print("family does not exit")}
  return(p)
}
