#' @title The function to calculate the value of the objective function
#' used in the estimation of the scalar-on-function generalized linear regression model
#' @description The function to calculate the value of the objective function
#' used in the estimation of the scalar-on-function generalized linear regression model.
#' @param N The design matrix.
#' @param Y The response variable vector.
#' @param c A vector of the B-spline basis coefficients.
#' @param lambda A non-negative smoothing parameter
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.
#' @param W A weight vector for each observation.
#' @param family A description of the distribution of the response variable.


#' @return The value of the objective function used in the
#' estimation of the scalar-on-function generalized
#' linear regression model.

obj_FGLM = function(N,Y,c,lambda,V,W,family)
{
  if(family == "Binomial") {result = sum(W*(Y*(N%*%c)-log(1+exp(N%*%c))))-lambda*(t(c)%*%V%*%c)/2}
  else if(family == "Possion") {result = sum(W*(Y*(N%*%c)-exp(N%*%c)-log(factorial(Y))))-lambda*(t(c)%*%V%*%c)/2}
  else {print("family does not exit")}
  return(result)
}

#' @title The function to calculate the value of the gradient function
#' used in the estimation of the scalar-on-function generalized linear regression model
#' @description The function to calculate the value of the gradient function
#' used in the estimation of the scalar-on-function generalized linear regression model.
#' @param N The design matrix.
#' @param Y The response variable vector.
#' @param c A vector of the B-spline basis coefficients.
#' @param lambda A non-negative smoothing parameter
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.
#' @param W A weight vector for each observation.
#' @param family A description of the distribution of the response variable.


#' @return The value of the gradient function used in the
#' estimation of the scalar-on-function generalized
#' linear regression model, which can be found in the equation (4.12)
#' of the reference Liu et al (2021).

#' @references H.Liu, J.You, J.Cao (2021).
#' Functional L-Optimality Subsampling for Massive Data.
#' @author Hua Liu, Jinhong You and Jiguo Cao


gr_FGLM = function(N,Y,c,lambda,V,W,family)
{
  result = t(N)%*%(W*(Y-psi(N%*%c,family)))-lambda*V%*%c
  return(result)
}

# The estimator of c using the subsample data selected by the FLoS
#' @title The function to get the estimator of B-spline basis coefficient
#' using the subsample data selected by the FLoS method for the
#' scalar-on-function generalized linear regression model

#' @description The function to get the estimator of basis coefficient
#' using the subsample data selected by the FLoS method for the
#' scalar-on-function generalized linear regression model,
#' which are described in Liu et al (2021) in the reference.

#' @param N The design matrix.
#' @param N_norm A vector with \emph{i}th element is the norm of
#' the \emph{i}th row of the design matrix N.
#' @param Y The response vector.
#' @param r The subsample size to draw a random subsample with replacement.
#' @param r0 The subsample size used to get the pilot estimator
#' of the basis coefficients.
#' @param lambda A non-negative smoothing parameter
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.
#' @param family A description of the distribution of the response variable.


#' @return A list of the following components
#' \itemize{
#' \item{c_FLoS} {A vector of the estimated B-spline basis coefficients using the
#' L-optimality motivated Algorithm 2 described in the reference Liu et al (2021).}
#' \item{c0} {A vector of the estimated initial B-spline basis coefficients used in
#' the Algorithm 2 of the reference Liu et al (2021).}
#' }
#' @references H.Liu, J.You, J.Cao (2021).
#' Functional L-Optimality Subsampling for Massive Data.
#' @author Hua Liu, Jinhong You and Jiguo Cao

FLoS_FGLM = function(N, N_norm, Y, r, r0, lambda, V,family)
{
  n = dim(N)[1]
  p = dim(N)[2]

  ###############################################
  #    Step 1: subsampel using the uniform      #
  #            sampling probabilities 1/n       #
  ###############################################
  index_uni0= sample(1:n,r0, replace = FALSE)
  N_uni0 = N[index_uni0,]
  Y_uni0 = Y[index_uni0]

  # calculate c0(without penalty)
  # if(family == "Binomial"){obj0 <- glm(Y_uni0~-1+N_uni0,family = binomial(link = "logit"))}
  # else if(family == "Possion") {obj0 <- glm(Y_uni0~-1+N_uni0,family = poisson(link = "log"))}
  # else {print("family does not exit")}
  c0 <- initial_FGLM(Y_uni0,N_uni0,family)

  ###############################################
  #    Step 2: calculate the sampling           #
  #            probabilities p_FLoS             #
  ###############################################
  y_prob0 <- psi(N %*% c0,family)
  res = Y - y_prob0
  p_FLoS = abs(res)*N_norm/sum(abs(res)*N_norm)

  # subsample using p_FLoS
  index_FLoS= sample(1:n,r, prob =  p_FLoS,replace = TRUE)
  N_FLoS = N[index_FLoS,]
  Y_FLoS = Y[index_FLoS]
  p_s_FLoS = p_FLoS[index_FLoS]
  W_FLoS = 1/(r*p_s_FLoS)

  ###############################################
  #    Step 3: estimate using the               #
  #            subsample data                   #
  ###############################################
  obj_FLoS <- optim(par = c0,fn = obj_FGLM,gr = gr_FGLM,
                    N=N_FLoS,Y=Y_FLoS,lambda=lambda,V=V,W=W_FLoS,family = family,
                    method = c("BFGS"),
                    control=list(fnscale=-1))
  c_FLoS = obj_FLoS$par

  return(list(c_FLoS = c_FLoS,c0=c0))
}



#' @title Estimating the B-spline basis coefficients
#' in the scalar-on-function generalized linear regression model
#' with roughness penalty with BIC using the subsample data selected
#' by the FLoS method
#' @description Estimating the B-spline basis coefficients
#' in the scalar-on-function generalized linear regression model
#' using the subsample data selected by the FLoS method,
#' which applies the B-spline basis expansion and
#' roughness penalty with BIC.


#' @param N The design matrix.
#' @param N_norm A vector with \emph{i}th element is the norm of
#' the \emph{i}th row of the design matrix N.
#' @param Y The response vector.
#' @param r The subsample size to draw a random subsample with replacement.
#' @param r0 The subsample size used to get the pilot estimator
#' of the basis coefficients.
#' @param lambda A sequence of non-negative smoothing parameters
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.
#' @param family A description of the distribution of the response variable.

#' @return A list of the following components
#' \itemize{
#' \item{c_FLoS} {A vector of the estimated B-spline basis coefficients using the
#' L-optimality motivated Algorithm 2 described in the reference Liu et al (2021).}
#' \item{lambda.FLoS} {The optimal smoothing parameter selected by BIC under
#' the optimal subsample data using FLoS method.}
#' \item{c0} {A vector of the estimated initial B-spline basis coefficients used in
#' the Algorithm 2 of the reference Liu et al (2021).}
#' }
#' @references H.Liu, J.You, J.Cao (2021).
#' Optimal Subsampling in Massive Data with Functional Predictors.
#' @author Hua Liu, Jinhong You and Jiguo Cao


FLoS_FGLM_BIC = function(N, N_norm, Y, r, r0, lambda, V,family)
{
  n = dim(N)[1]
  # p = dim(N)[2]

  ###############################################
  #    Step 1: subsampel using the uniform      #
  #            sampling probabilities 1/n       #
  ###############################################
  index_uni0= sample(1:n,r0, replace = FALSE)
  N_uni0 = N[index_uni0,]
  Y_uni0 = Y[index_uni0]

  # calculate c0(without penalty)
  # if(family == "Binomial"){obj0 <- glm(Y_uni0~-1+N_uni0,family = binomial(link = "logit"))}
  # else if(family == "Possion") {obj0 <- glm(Y_uni0~-1+N_uni0,family = poisson(link = "log"))}
  # else {print("family does not exit")}
  c0 <- initial_FGLM(Y_uni0,N_uni0,family)

  ###############################################
  #    Step 2: calculate the sampling           #
  #            probabilities p_FLoS             #
  ###############################################
  y_prob0 <- psi(N %*% c0,family)
  res = Y - y_prob0
  p_FLoS = abs(res)*N_norm/sum(abs(res)*N_norm)

  # subsample using p_FLoS
  index_FLoS= sample(1:n,r, prob =  p_FLoS,replace = TRUE)
  N_FLoS = N[index_FLoS,]
  Y_FLoS = Y[index_FLoS]
  p_s_FLoS = p_FLoS[index_FLoS]
  W_FLoS = 1/(r*p_s_FLoS)

  ###############################################
  #    Step 3:  choosing the optimal lambda     #
  #        based on the optimal subsample data  #
  ###############################################
  nlambda   = length(lambda)
  bic_FLoS = array(NA,nlambda)
  for (i in 1:nlambda)
  {
    # calculate df
    A = t(N_FLoS)%*%diag(W_FLoS)%*%N_FLoS+lambda[i]*V
    hat_matrix = N_FLoS%*%ginv(A)%*%t(N_FLoS)
    df = tr(hat_matrix)
    rm(A,hat_matrix)
    # calculate beta for each lambda
    obj_bic <- optim(par = c0,fn = obj_FGLM,gr = gr_FGLM,
                     N=N_FLoS,Y=Y_FLoS,lambda=lambda[i],V=V,W=W_FLoS,
                     family = family,
                     method = c("BFGS"),
                     control=list(fnscale=-1))

    c_bic = obj_bic$par

    # log-likelihood
    # if(family == "Binomial"){
    #       l = (-sum(log(1+exp(N_FLoS[Y_FLoS<= 0, ] %*% c_bic))) -
    #             sum(log(1+exp(-N_FLoS[Y_FLoS>0,] %*% c_bic))))}
    # else if (family == "Possion") {
    #        l = sum(Y_FLoS*(N_FLoS%*%c_bic)-exp(N_FLoS%*%c_bic)-
    #                  log(factorial(Y_FLoS)))
    # }
    # else {print("family does not exit")}
    #

    l = loglik_FGLM(Y_FLoS,N_FLoS,c_bic,family)
    # bic_FLoS[i] = -2*l/r + log(r)*df
    bic_FLoS[i] = -l/r + log(r)*df

  }
  idx = which(bic_FLoS == min(bic_FLoS), arr.ind = TRUE)
  lambda_FLoS = lambda[idx]

  ###############################################
  #    Step 4: estimate using the               #
  #            subsample data                   #
  ###############################################
  obj_FLoS <- optim(par = c0,fn = obj_FGLM,gr = gr_FGLM,
                    N=N_FLoS,Y=Y_FLoS,lambda=lambda_FLoS,V=V,W=W_FLoS,
                    family = family,
                    method = c("BFGS"),
                    control=list(fnscale=-1))
  c_FLoS = obj_FLoS$par

  return(list(c_FLoS = c_FLoS,lambda_FLoS=lambda_FLoS,c0=c0))
}
