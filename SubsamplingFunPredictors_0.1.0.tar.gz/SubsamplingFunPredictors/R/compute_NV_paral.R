#' @title  Get the design matrix,
#' basis roughness penalty matrix
#' and basis function values matrix in parallel
#' @description The parallel function to get the design matrix N  
#' (save as several csv files),
#' the norm vector of each row of N,
#' the square symmetric basis roughness penalty matrix V,
#' and a matrix of basis function values basismat.
#'
#' @param file The file of the functional predictor, in which
#' each row is an observation vector;
#' each column corresponds to observed trajectory at design points.
#' @param K A positive integer; the inner knots used to expand the slop function.
#' @param d A positive integer that specifies the degree of the
#' B-spline basis used to expand the slop function.
#' @param domain An array of two numbers that specifies domain
#' for functional predictor.
#'
#'
#' @return
#' \itemize{
#' \item{selN} {A split selectrows x (K+d+1) design matrix; the \emph{(ij)}th element equals to the integral of the \emph{i}th predictor and the \emph{j}th B-spline basis function, which is not returned but saved as csv file.}
#' \item{V} {A (K+d+1) x (K+d+1) square symmetric basis roughness penalty matrix whose order is equal to the number of B-spline basis functions used to expand the slop function.}
#' \item{basismat} {An T x (K+d+1) matrix
#' of basis function values with rows corresponding to argument values
#' and columns to basis functions.}
#' \item{N_norm} {An n x 1 vector; the \emph{i}th element is the norm of
#' the \emph{i}th row of the design matrix N.}
#' }

#' @references H.Liu, J.You, J.Cao (2021).
#' Functional L-Optimality Subsampling for Massive Data.
#' @author Hua Liu, Jinhong You and Jiguo Cao
#' @importFrom  data.table

compute_NV_paral = function(file,K,d,domain){
  
  # single core function 
  compute_NV_single = function(ichunks,ncores,file,K,d,domain){
    
    # check the total row numbers(plus the column name line)
    rownum = nrow(fread(file,skip =  1))
    
    # selected rows on each core
    selrow = ceiling(rownum/ncores)
    
    # extract subdata
    if(ichunks < ncores) {
      sel= fread(file,nrow = selrow,skip = (ichunks-1)*selrow+1, data.table = "FLASE")
    }
    else if(ichunks == ncores) {
      sel = fread(file,skip = (ichunks-1)*selrow+1, data.table = "FLASE")
    }
    else {print("ncores exits the total avaliable cores")}
    
    # run compute.NV on each subdata
    sel = data.matrix(sel)
    nc = dim(sel)[1]
    T = dim(sel)[2]
    selmean = colMeans(sel)
    selc = sel - matrix(rep(selmean,nc),nrow=nc,byrow= T)
    selNV = compute.NV(selc,K,d,domain)
    selN = selNV$N
    selV = selNV$V
    selN_norm = selNV$N_norm
    basismat = selNV$basismat
    write.csv(selN,paste0("sel",ichunks, ".csv"), row.names = FALSE)
    result = list(selV = selV, basismat = basismat,selN_norm = selN_norm)
    return(result)
  }
  
  # specify target number of cores, e.g. 4 or 8
  initmc <- function(nworkers) {
    makeCluster(spec = nworkers)
  }
  
  ncores = detectCores()
  cls = initmc(ncores)
  
  # parallel:::setDefaultClusterOptions(setup_strategy = "sequential")
  
  mutoutpar <- function(cls, ncores, file,K,d,domain) { 
    
    clusterEvalQ(cls, 
                 {library("SubsamplingFunPredictors");
                   library("fda");
                   library("MASS");
                   library("psych");
                   library("wordspace");
                   library("data.table")}) # specify the required libraries or source codes
    ichunks <- 1:ncores
    clusterApply(cls, ichunks, compute_NV_single, ncores,file,K,d,domain) 
    
  }
  
  timestart <- Sys.time()
  simuloutcome <- mutoutpar(cls, ncores, file,K,d,domain)
  timeend <- Sys.time()
  runningtime<- timeend-timestart
  print(runningtime)
  stopCluster(cls)
  
  # pool_r_all = do.call('rbind',simuloutcome[[2]])
  # pool_r_all  = do.call(simuloutcome, c(f = rbind, nestedlist))
  
  N_norm = as.vector(do.call(rbind,lapply(simuloutcome, `[[`, 3)))
  V = data.matrix(simuloutcome[[1]]$selV)
  basismat = data.matrix(simuloutcome[[1]]$basismat)
  result = list(N_norm=N_norm, V = V,basismat = basismat)
  return(result)
  
}
