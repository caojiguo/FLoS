#' @title The BIC value under the scalar-on-function linear model
#' @description The BIC value under the scalar-on-function linear model.
#' @param Y An n x 1 response vector.
#' @param N A design matrix.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.
#' @param n The number of observation.
#' @param lambda A non-negative smoothing parameter
#' for the roughness penalty.
#' @param W An n x n weight diagonal matrix.
#' The \emph{i}th diagonal element is the weight of the \emph{i}th observation.

#' @return The BIC value.
#' @references H.Liu, J.You, J.Cao (2021).
#' Functional L-Optimality Subsampling for Massive Data.
#' @author Hua Liu, Jinhong You and Jiguo Cao

#' @importFrom MASS psych
BIC_FLoS = function(Y, N, V, n, lambda,W)
{
  A = t(N)%*%W%*%N+lambda*V
  B = t(N)%*%W%*%Y
  c = MASS::ginv(A)%*%B
  Yhat = N%*%c
  hat = N%*%MASS::ginv(A)%*%t(N)
  df  = psych::tr(hat)
  SSE = t(Y - Yhat)%*%(Y - Yhat)
  BIC.FLoS = n*log(SSE/n) + log(n)*df
  return(BIC.FLoS = BIC.FLoS)
}
