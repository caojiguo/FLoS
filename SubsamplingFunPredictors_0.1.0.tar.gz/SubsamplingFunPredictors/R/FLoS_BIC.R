#' @title Estimating the B-spline basis coefficients
#' in the scalar-on-function linear regression model
#' with roughness penalty with BIC using the subsample data selected
#' by the FLoS method
#' @description Estimating the B-spline basis coefficients
#' in the scalar-on-function linear regression model
#' using the subsample data selected by the FLoS method,
#' which applies the B-spline basis expansion and
#' roughness penalty with BIC.
#' @param N The design matrix.
#' @param N_norm A vector with \emph{i}th element is the norm of
#' the \emph{i}th row of the design matrix N.
#' @param yc The centered response vector.
#' @param r The subsample size to draw a random subsample with replacement.
#' @param r0 The subsample size used to get the pilot estimator
#' of the basis coefficients.
#' @param lambda A sequence of non-negative smoothing parameters
#' for the roughness penalty.
#' @param V A square symmetric basis roughness
#' penalty matrix whose order is equal to the number of B-spline basis
#' functions used to expand the slop function.
#' @return A list of the following components
#' \itemize{
#' \item{c_FLoS} {A vector of the estimated B-spline basis coefficients using the
#' L-optimality motivated Algorithm 1 described in the reference Liu et al (2021).}
#' \item{lambda.FLoS} {The optimal smoothing parameter selected by BIC under
#' the optimal subsample data using FLoS method.}
#' }
#' @references H.Liu, J.You, J.Cao (2021).
#' Functional L-Optimality Subsampling for Massive Data.
#' @author Hua Liu, Jinhong You and Jiguo Cao
FLoS_BIC = function(N, N_norm, yc, r, r0, lambda, V )
{
  n = dim(N)[1]

  ###############################################
  #    Step 1: subsampel using the uniform      #
  #            sampling probabilities 1/n       #
  ###############################################
  index_uni0= sample(1:n,r0, replace = FALSE)
  N_uni0 = N[index_uni0,]
  y_uni0 = yc[index_uni0]

  # calculate c0
  A0 = t(N_uni0)%*%N_uni0
  B0 = t(N_uni0)%*%y_uni0
  # c0 = ginv(t(N_uni0)%*%N_uni0+lambda*V)%*%t(N_uni0)%*%y_uni0
  c0 = ginv(A0)%*%B0

  ###############################################
  #    Step 2: calculate the sampling           #
  #            probabilities p_FLoS             #
  ###############################################
  # N_norm = apply(N,1,norm,"2")
  # N_norm = rowNorms(N, "euclidean")
  res = yc - N%*%c0
  p_FLoS = abs(res)*N_norm/sum(abs(res)*N_norm)

  # subsample using p_FLoS
  index_FLoS= sample(1:n,r, prob =  p_FLoS,replace = TRUE)
  N_FLoS = N[index_FLoS,]
  y_FLoS = yc[index_FLoS]
  p_s_FLoS = p_FLoS[index_FLoS]
  W_FLoS = diag(1/(r*p_s_FLoS))


  ###############################################
  #    Step 3:  choosing the optimal lambda     #
  #        based on the optimal subsample data  #
  ###############################################
  nlambda   = length(lambda)
  bic.FLoS = array(NA,nlambda)
  for (i in 1:nlambda)
  {
    bic.FLoS[i] = BIC_FLoS(y_FLoS, N_FLoS, V, r, lambda[i], W_FLoS)
  }

  idx = which(bic.FLoS == min(bic.FLoS), arr.ind = TRUE)
  lambda.FLoS = lambda[idx]

  ###############################################
  #    Step 4: estimate using the               #
  #            subsample data                   #
  ###############################################
  # estimate using the subsample data
  A_FLoS = t(N_FLoS)%*%W_FLoS%*%N_FLoS+lambda.FLoS*V
  B_FLoS = t(N_FLoS)%*%W_FLoS%*%y_FLoS
  c_FLoS = ginv(A_FLoS)%*%B_FLoS

  return(list(c_FLoS = c_FLoS,lambda.FLoS=lambda.FLoS))
}
