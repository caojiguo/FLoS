#' @title The function to calculate the maximized value of the log likelihood funtion

#' @description The function to calculate the maximized value of the
#' log likelihood function of the
#' scalar-on-function generalized linear regression model described
#' in the reference Liu et al (2021).

#' @param Y The response variable vector.
#' @param N The design matrix.
#' @param c A vector of the estimated B-spline basis coefficients.
#' @param family A description of the distribution of the response variable.

#' @return The maximized value of the log likelihood function of the
#' scalar-on-function generalized linear regression model using the
#' estimated B-spline basis coefficients c.

#' @references H.Liu, J.You, J.Cao (2021).
#' Functional L-Optimality Subsampling for Massive Data.
#' @author Hua Liu, Jinhong You and Jiguo Cao


loglik_FGLM = function(Y,N,c,family)
{
  if(family == "Binomial"){
    l = (-sum(log(1+exp(N[Y<= 0, ] %*% c))) -
           sum(log(1+exp(-N[Y>0,] %*% c))))}
  else if (family == "Possion") {
    l = sum(Y*(N%*%c)-exp(N%*%c)-
              log(factorial(Y)))
  }
  else {print("family does not exit")}
  return(l)
}
